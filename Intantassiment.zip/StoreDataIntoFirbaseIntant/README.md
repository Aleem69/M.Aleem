# StoreDataIntoFirbaseIntant
Simple android app to pass data from one activity to another activity with explicit intent and than store data to Firebase Datastore.
# Show Your Support
* [Recommend Me On LinkedIn](https://www.linkedin.com/in/imalisheraz/) - I will realy Appriciate this  
* Don't forget to star ⭐ the repo 😉, it's FREE.

# Requirements
* Any Operating System.   
* Android Studio.
